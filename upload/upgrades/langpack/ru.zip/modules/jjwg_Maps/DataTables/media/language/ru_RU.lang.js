{
    "sEmptyTable":     "Таблица пуста",
    "sInfo":           "Показано от _START_ до _END_ из _TOTAL_ записей",
    "sInfoEmpty":      "Показано от 0 до 0 из 0 записей",
    "sInfoFiltered":   "(отфильтровано из _MAX_ всего записей)",
    "sInfoPostFix":    "",
    "sInfoThousands":  ",",
    "sLengthMenu":     "Показ _MENU_ записи",
    "sLoadingRecords": "Загрузка...",
    "sProcessing":     "Процесс идёт...",
    "sSearch":         "Поиск:",
    "sZeroRecords":    "Нет записей, которые соответствуют запросу",
    "oPaginate": {
        "sFirst":    "Первая",
        "sLast":     "Последняя",
        "sNext":     "Следующая",
        "sPrevious": "Предыдущая"
    },
    "oAria": {
        "sSortAscending":  ": сортировать колонки по возрастанию",
        "sSortDescending": ": сортировать колонки по убыванию"
    }
}